class Program
{
    static HttpClient httpClient = new HttpClient();
    static async Task Main()
    {
        HttpContent content = new StringContent("Hello METANIT.COM");
        // ������������� ��������� 
        content.Headers.Add("SecreteCode", "Anything");

        using var response = await httpClient.PostAsync("https://localhost:7094/", content);
        string responseText = await response.Content.ReadAsStringAsync();
        Console.WriteLine(responseText);
    }
}