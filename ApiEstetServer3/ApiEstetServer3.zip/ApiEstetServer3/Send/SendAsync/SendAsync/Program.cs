﻿class Program
{
    static HttpClient httpClient = new HttpClient();
    static async Task Main()
    {
        StringContent content = new StringContent("Сообшение от сервера...");
        // определяем данные запроса
        using var request = new HttpRequestMessage(HttpMethod.Post, "https://localhost:7094/data");
        // установка отправляемого содержимого
        request.Content = content;
        // отправляем запрос
        using var response = await httpClient.SendAsync(request);
        // получаем ответ
        string responseText = await response.Content.ReadAsStringAsync();
        Console.WriteLine(responseText);
    }
}