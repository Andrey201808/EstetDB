
INSERT INTO "Lessons" VALUES (1,'Фортепиано','https://www.youtube.com/playlist?list=PLIiklUOW1Aj64LRlEdfFlpaSaq2RPZWO3','ГБУДО г. Москвы ДМШ им. К.Н.Игумнова',88,'Иванов И.А','http://igumnov.music.mos.ru/')
INSERT INTO "Lessons" VALUES (2,'струнные инструменты','https://yandex.ru/video/preview/13657299184609103752','ГБУДО г. Москвы ДМШ им. К.Н.Игумнова',85,'Иванова Е.А','http://igumnov.music.mos.ru/')
INSERT INTO "Lessons" VALUES (3,'духовые и ударные инструменты','https://www.youtube.com/watch?v=54xgZH3FulA','ГБУДО г. Москвы ДМШ им. К.Н.Игумнова',88,'Петров П.П.','http://igumnov.music.mos.ru/')
INSERT INTO "Lessons" VALUES (4,'народные инструменты','https://ok.ru/video/372259620109','ГБУДО г. Москвы ДМШ им. К.Н.Игумнова',88,'Сидоров К.А','http://igumnov.music.mos.ru/')

SELECT * FROM "Lessons"