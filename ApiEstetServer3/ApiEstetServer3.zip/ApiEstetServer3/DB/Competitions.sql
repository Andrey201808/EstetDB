
INSERT INTO "Competitions" VALUES (1,'Бунакова','Специалист','+79058235245','Дизайн',99)
INSERT INTO "Competitions" VALUES (2,'Козаченко','Эксперт','','Дизайн',99)
INSERT INTO "Competitions" VALUES (3,'Лабунский','Начинающий','+79254738803','Программист',99)
INSERT INTO "Competitions" VALUES (4,'Никулин','Профессионал','+79269474200','Программист',99)
INSERT INTO "Competitions" VALUES (5,'Степанов','Любитель','+79649903926','Программист',99)

SELECT * FROM "Competitions"