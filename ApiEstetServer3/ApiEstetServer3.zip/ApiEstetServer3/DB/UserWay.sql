
INSERT INTO "UserWay" VALUES (1,'Katerina-810@mail.ru','https://www.behance.net/KateBunakova','Бунакова Екатерина','https://www.behance.net/KateBunakova',0,'',99)
INSERT INTO "UserWay" VALUES (2,'ariamsaab1983@gmail.com','https://vk.com/alenakozachenko','Козаченко Алена','https://vk.com/alenakozachenko',0,'',99)
INSERT INTO "UserWay" VALUES (3,'labworkspace@yandex.ru','','Лабунский Андрей','',0,'',99)
INSERT INTO "UserWay" VALUES (4,'nikulin9810@yandex.ru','','Никулин Алексей','',0,'',99)
INSERT INTO "UserWay" VALUES (5,'pochta201002@mail.ru','https://vk.com/id1240707','Степанов Андрей','https://vk.com/id1240707',0,'',99)

SELECT * FROM "UserWay"