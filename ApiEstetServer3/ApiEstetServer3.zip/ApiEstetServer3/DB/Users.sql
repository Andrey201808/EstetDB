INSERT INTO "Users" VALUES (1,'BunakovaE','pass','Designer')
INSERT INTO "Users" VALUES (2,'ANikulin','pass1','Developer')
INSERT INTO "Users" VALUES (3,'AKozachenko','pass2','Designer')
INSERT INTO "Users" VALUES (4,'ALabunskiy','pass3','Developer')
INSERT INTO "Users" VALUES (5,'AStepanov','pass4','Developer')

SELECT * FROM "Users"