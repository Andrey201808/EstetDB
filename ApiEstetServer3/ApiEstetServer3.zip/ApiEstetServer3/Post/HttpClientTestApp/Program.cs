var builder = WebApplication.CreateBuilder();
var app = builder.Build();

app.MapPost("/data", async (HttpContext httpContext) =>
{
    using StreamReader reader = new StreamReader(httpContext.Request.Body);
    string name = await reader.ReadToEndAsync();
    return $"�������� ������: {name}";
});

app.Run();
