class Program
{
    static HttpClient httpClient = new HttpClient();
    static async Task Main()
    {
        StringContent content = new StringContent("Tom");
        using var response = await httpClient.PutAsync("https://localhost:7094/data", content);
        string responseText = await response.Content.ReadAsStringAsync();
        Console.WriteLine(responseText);
    }
}