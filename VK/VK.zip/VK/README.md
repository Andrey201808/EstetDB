# VkAPITutorial
FIles for tutorial https://habrahabr.ru/post/314518/
